
import React, { useState } from 'react';
import { CASE_RESULTS } from '../constants';
import { Filter, Search, Scale, ShieldAlert, TrendingUp } from 'lucide-react';

export const Results: React.FC = () => {
  const [filter, setFilter] = useState('All');

  const filteredResults = filter === 'All' 
    ? CASE_RESULTS 
    : CASE_RESULTS.filter(r => r.category === filter);

  return (
    <div className="pt-32 bg-gray-50 min-h-screen">
      <section className="bg-primary text-white py-24 mb-16 relative overflow-hidden">
        <div className="container mx-auto px-6 relative z-10 text-center">
          <p className="text-accent-gold font-bold uppercase tracking-[0.3em] mb-4">Proven Performance</p>
          <h1 className="text-6xl md:text-8xl mb-8">CASE VICTORIES.</h1>
          <div className="flex flex-wrap justify-center gap-4 mt-12">
            {['All', 'Criminal', 'Injury'].map((cat) => (
              <button 
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-8 py-3 font-bold uppercase tracking-widest text-xs transition-all border-2 ${
                  filter === cat ? 'bg-accent-gold border-accent-gold' : 'border-white/20 hover:border-white'
                }`}
              >
                {cat} Cases
              </button>
            ))}
          </div>
        </div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-5 pointer-events-none">
          <Scale size={600} />
        </div>
      </section>

      <section className="container mx-auto px-6 pb-32">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredResults.map((result, idx) => (
            <div key={idx} className="bg-white p-10 border border-gray-100 hover:shadow-2xl transition-all group flex flex-col h-full">
              <div className="flex justify-between items-start mb-8">
                <div className={`p-3 ${result.category === 'Criminal' ? 'bg-black text-white' : 'bg-accent-gold text-white'}`}>
                  {result.category === 'Criminal' ? <ShieldAlert size={20}/> : <TrendingUp size={20}/>}
                </div>
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{result.category} Case</span>
              </div>
              <h3 className="text-3xl font-heading mb-4 text-primary leading-tight flex-grow">{result.outcome}</h3>
              <p className="text-accent-gold font-bold text-sm mb-6 tracking-wide">"{result.title}"</p>
              <div className="w-12 h-0.5 bg-gray-200 mb-6 transition-all group-hover:w-full group-hover:bg-accent-gold"></div>
              <p className="text-gray-500 leading-relaxed text-sm">
                {result.description}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-24 text-center bg-white p-16 border border-gray-100">
           <h4 className="text-3xl mb-6 italic">Looking for results similar to your situation?</h4>
           <p className="text-gray-500 mb-10 max-w-2xl mx-auto">Every case is unique. While past performance does not guarantee future results, it demonstrates our firm's ability to handle high-stakes legal challenges.</p>
           <a href="tel:1800MCKENNA" className="inline-block bg-primary text-white px-12 py-5 font-bold uppercase tracking-widest hover:bg-accent-gold transition-all">
             Discuss Your Case Anonymously
           </a>
        </div>
      </section>
    </div>
  );
};
